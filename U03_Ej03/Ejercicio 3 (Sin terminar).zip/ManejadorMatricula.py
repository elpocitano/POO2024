from Matricula import Matricula
class ManejadorMatricula:
    __listaMatriculas: list

    def __init__(self):
        self.__listaMatriculas = []

    def __str__(self):
        cadena = ""
        for matricula in self.__listaMatriculas:
            cadena = cadena + int(matricula) + "\n"
    
    def agregarMatricula(self, unMatricula):
        self.__listaMatriculas.append(unMatricula)

    def consultarDuracion(self, id):
        bandera = False
        i = 0
        duracionTotal = 0
        for matricula in self.__listaMatriculas:
            if matricula.getEmpleado().getIdEmpleado() == id:
                duracionTotal = duracionTotal + matricula.getDuracionPrograma()



    
    #P

    