class ProgramaCapacitacion:
    __nombre: str
    __codigo: str
    __duracion: int
    __listaMatriculas: list

    def __init__(self, nombre, codigo, duracion):
        self.__nombre = nombre
        self.__codigo = codigo
        self.__duracion = duracion
        self.__listaMatriculas = []

    def __str__(self):
        return f"Nombre: {self.__nombre} Codigo: {self.__codigo} Duracion: {self.__duracion}"

    def getNombre(self):
        return self.__nombre
    
    def getCodigo(self):
        return self.__codigo
    
    def getDuracion(self):
        return self.__duracion
    
    def getMatricula(self):      #Duda
        return self.__listaMatriculas
    
    def agregarMatricula(self, unaMatricula):
        self.__listaMatriculas.append(unaMatricula)

    

    

