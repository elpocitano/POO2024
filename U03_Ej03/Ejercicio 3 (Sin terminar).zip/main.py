from ManejadorProgramaCapacitacion import ManejadorProgramaCapacitacion
from ManejadorEmpleados import ManejadorEmpleados
from ManejadorMatricula import ManejadorMatricula
from Matricula import Matricula


if __name__ == "__main__":
    mMatricula = ManejadorMatricula()

    mEmpleados = ManejadorEmpleados()
    mEmpleados.cargaEmpleados() 

    mProgramas = ManejadorProgramaCapacitacion()
    mProgramas.cargaProgramasCapacitacion()



    opcion = input("Ingrese opcion...")

    while opcion != "0":

        if opcion == "1":
            xNombre = input("Ingrese Nombre del empleado:  ")
            xPrograma = input("Ingrese Nombre del programa:  ")
            empleadoBuscado = ManejadorEmpleados.obtenerEmpleado(xNombre)
            programaBuscado = ManejadorProgramaCapacitacion.obtenerPrograma(xPrograma)
            if empleadoBuscado == None:
                print("El empleado no existe")
            else:
                if programaBuscado == None:
                    print("El programa no existe")
                else:
                    fecha = input("Ingrese fecha de matricula: ") 
                    matriculaNueva = Matricula(fecha, empleadoBuscado, programaBuscado)
                    empleadoBuscado.agregarMatricula(matriculaNueva)
                    programaBuscado.agregarMatricula(matriculaNueva)
                    mMatricula.agregarMatricula(matriculaNueva)
                    print("Matricula agregada correctamente")

        elif opcion == "2":
            xID = input("Ingrese ID del empleado")

            if mEmpleados.existe(xID) == True:
                mMatricula.consultarDuracion(xID) 
                print(f"Duracion total de todos los programas: {mMatricula.consultarDuracion(xID)}")
            else:
                print("El ID ingresado no existe")
            
        elif opcion == "3":
            xPrograma = input("Ingrese nombre del programa")

            #eso se lo consultaria al mismos manejador de programas?
            if mProgramas.existe(xPrograma) == True:
                mProgramas.consultarInscriptos(xPrograma)
            else:
                print("El programa no existe")

        