from ProgramaCapacitacion import ProgramaCapacitacion
class ManejadorProgramaCapacitacion:
    __listaProgramasCap : list

    def __init__(self):
        self.__listaProgramasCap = []

    def __str__(self):
        cadena = ""
        for programa in self.__listaProgramasCap
            cadena = cadena + str(programa) +"\n"
        return cadena
    
    def agregarPrograma(self, unPrograma):
        self.__listaProgramasCap.append(unPrograma)

    def cargaProgramasCapacitacion(self):
        archivo = open("datosProgramasCapacitacion.csv")
        reader = csv.reader(archivo, delimiter=";")
        bandera = True
        for fila in reader:
            if bandera == True:
                bandera = False
            else:
                nombre = fila[0]
                codigo = int(fila[1])
                duracion = int(fila[2])
                unPrograma = ProgramaCapacitacion(nombre, codigo, duracion)
                self.agregarPrograma(unPrograma)
        archivo.close

    def obtenerPrograma(self, nombrePrograma):
        retorno = None
        bandera = False
        i=0
        while i < len(self.__listaProgramasCap) and not bandera:
            if self.__listaProgramasCap[i].getNombreApellido() == nombrePrograma:
                retorno = self.__listaProgramasCap[i]
                bandera = True 
            else:
                i=i+1
        return retorno
    
    def existe(self, programa):
        bandera = False
        i = 0
        while i < len(self.__listaProgramasCap) and not bandera:
            if self.__listaProgramasCap[i].getNombre() == programa:
                bandera = True
        return bandera


    def consultarInscriptos(self, nombre):
        for programa in self.__listaProgramasCap: #Ahhh bien bien
            if programa.getNombre() == nombre:
                for matricula in                                                               
            programa.getNombre()

            #Es el 2 profe

