class Empleado:
    __nombreApellido: str
    __idEmpleado: int
    __puesto: str
    __listaMatriculas: list

    def __init__(self, nombreApellido, idEmpleado, puesto):
        self.__nombreApellido = nombreApellido
        self.__idEmpleado = idEmpleado
        self.__puesto = puesto
        self.__listaMatriculas = []


    def __str__(self):
        return f"Nombre y Apellido {self.__nombreApellido} ID: {self.__idEmpleado} Puesto: {self.__puesto} "
    
    def getNombreApellido(self):
        return self.__nombreApellido
    
    def getIdEmpleado(self):
        return self.__idEmpleado
    
    def getPuesto(self):
        return self.__puesto
    
    def agregarMatricula(self, unaMatricula):
        self.__listaMatriculas.append(unaMatricula)
