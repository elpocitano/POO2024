from Empleado import Empleado
class ManejadorEmpleados:
    __listaEmpleados = list

    def __init__(self):
        self.__listaEmpleados = []
        
    def __str__(self):
        cadena = ""
        for empleado in self.__listaEmpleados:
            cadena = cadena + str(empleado) +"\n"
        return cadena
    
    def agregarEmpleado(self, unEmpleado):
        self.__listaEmpleados.append(unEmpleado)

    def cargaEmpleados(self):
        archivo = open("datosEmpleados.csv")
        reader = csv.reader(archivo, delimiter=";")
        bandera = True
        for fila in reader:
            if bandera == True:
                bandera = False
            else:
                nombreApelldo = fila[0]
                id = int(fila[1])
                puesto = fila[2]
                unEmpleado = Empleado(nombreApelldo, id, puesto)
                self.agregarEmpleado(unEmpleado)
        archivo.close

    def obtenerEmpleado(self, nombreEmpleado):
        retorno = None
        bandera = False
        i=0
        while i < len(self.__listaEmpleados) and not bandera:
            if self.__listaEmpleados[i].getNombreApellido() == nombreEmpleado:
                retorno = self.__listaEmpleados[i]
                bandera = True #gracias
            else:
                i=i+1
        return retorno

    def existe(self, id):
        bandera = False
        i = 0
        while i < len(self.__listaEmpleados) and not bandera:
            if self.__listaEmpleados[i].getIdEmpleado() == id:
                bandera = True
        return bandera

    