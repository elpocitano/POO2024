from Empleado import Empleado
from ProgramaCapacitacion import ProgramaCapacitacion
class Matricula:
    __fecha: str 
    __empleado: Empleado
    __programa: ProgramaCapacitacion 

    def __init__(self, fecha, empleado, programa):
        self.__fecha = fecha
        self.__empleado = empleado
        self.__programa = programa

    def getFecha(self):
        return self.__fecha
    
    def getEmpleado(self):
        return self.__empleado
    
    def getPrograma(self):
        return self.__programa
    
    def getDuracionPrograma(self):
        return self.__programa.getDuracion()
    

