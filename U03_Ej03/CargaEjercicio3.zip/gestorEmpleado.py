import csv
from claseEmpleado import *
class GestorEmpleado:
    __listado:list
    
    def __init__(self,lista=[]) -> None:
        self.__listado = lista
        
    def carga(self):
        bandera=True
        archivo = open(
            r"C:\Users\erica\OneDrive\Documents\Pythonfacultad\unidad3\ejercicio3\Empleados.csv")
        reader = csv.reader(archivo, delimiter=',')
        for fila in reader:
            c=Empleado(fila[0],int(fila[1]),fila[2])
            self.__listado.append(c)
    def muestra(self):
        for i in self.__listado:
            print(i)