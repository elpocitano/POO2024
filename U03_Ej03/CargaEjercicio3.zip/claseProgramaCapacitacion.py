class ProgramaCapacitacion:
    __nombre:str
    __codigo:str
    __duracion:str
    
    def __init__(self,nombre,codigo,duracion) -> None:
        self.__nombre=nombre
        self.__codigo=codigo
        self.__duracion=duracion
        
    def __str__(self) -> str:
        return f"{self.__nombre} {self.__codigo} {self.__duracion}"
    
    def getnombre(self):
        return self.__nombre
    def getcodigo(self):
        return self.__codigo
    def getduracion(self):
        return self.__duracion