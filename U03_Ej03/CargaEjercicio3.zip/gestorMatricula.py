import csv
from claseMatricula import *
from claseEmpleado import *
from claseProgramaCapacitacion import *
class gestorMatricula:
    __listado:list
    
    def __init__(self,lista=[]) -> None:
        self.__listado = lista
        
    def agregar(self,matricula):
        self.__listado.append(matricula)
    def carga(self):
        archivo = open(
            r"C:\Users\erica\OneDrive\Documents\Pythonfacultad\unidad3\ejercicio3\Matricula.csv")
        reader = csv.reader(archivo, delimiter=',')
        for fila in reader:
            emp=Empleado(fila[1],int(fila[2]),fila[3])
            programa=ProgramaCapacitacion(fila[4],fila[5],fila[6])
            m=Matricula(fila[0],emp,programa)
            self.agregar(m)
    def muestra(self):
        for i in self.__listado:
            print(i)