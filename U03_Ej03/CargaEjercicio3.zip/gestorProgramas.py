import csv
from claseProgramaCapacitacion import *
class GestorPrograma:
    __lista:license
    
    def __init__(self,lista=[]) -> None:
        self.__lista = lista
        
    def cargaPrograma(self):
        bandera=True
        archivo = open(
            r"C:\Users\erica\OneDrive\Documents\Pythonfacultad\unidad3\ejercicio3\Programas.csv")
        reader = csv.reader(archivo, delimiter=',')
        for fila in reader:
            c=ProgramaCapacitacion(fila[0],fila[1],fila[2])
            self.__lista.append(c)
    def muestraPrograma(self):
        for i in self.__lista:
            print("\n")
            print(i)