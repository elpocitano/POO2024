class Empleado:
    __nombreApellido:str
    __idEmpleado:int
    __puesto: str
    
    def __init__(self,nombreApellido,idEmpleado,puesto):
        self.__nombreApellido = nombreApellido
        self.__idEmpleado = idEmpleado
        self.__puesto = puesto
        
    def __str__(self) -> str:
        return f"{self.__nombreApellido} {self.__idEmpleado} {self.__puesto}"
    
    def getNombreApellido(self):
        return self.__nombreApellido
    
    def getIdEmpleado(self):
        return self.__idEmpleado
    
    def getPuesto(self):
        return self.__puesto