from claseEmpleado import *
from claseProgramaCapacitacion import *
class Matricula:
    __fecha:str
    __empleados:Empleado
    __programa:ProgramaCapacitacion
    
    def __init__(self,fecha,empleados=None,programa=None):
        self.fecha = fecha
        self.__empleados=empleados
        self.__programa=programa
    def __str__(self) -> str:
        return f"{self.fecha} {self.__empleados} {self.__programa}"
    def getFecha(self):
        return self.fecha
    def getEmpleados(self):
        return self.__empleados
    def getPrograma(self):
        return self.__programa