import os
from gestorMatricula import *
from gestorProgramas import *
from gestorEmpleado import *
if __name__ == "__main__":
    GE=GestorEmpleado()
    GP=GestorPrograma()
    GM=gestorMatricula()
    os.system("cls")
    print("**MENU**")
    print("1: Cargar")
    print("2: Mostrar")
    print("3: Salir")
    opcion = int(input("op1: carga empleados\nop2:carga Programa\n op3: carga Matriculas \nIngrese una opcion:  "))
    while opcion:
        if opcion == 1:
            print("Cargar")
            GE.carga()
            GE.muestra()
        elif opcion == 2:
            GP.cargaPrograma()
            GP.muestraPrograma()
        elif opcion == 3:
            GM.carga()
            GM.muestra()
        opcion = int(input("Ingrese una opcion: "))
        